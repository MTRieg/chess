#include "player.h"
#include "piece.h"

Colour Player::getColour() const {
    return colour;
}
