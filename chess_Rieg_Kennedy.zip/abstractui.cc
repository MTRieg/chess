#include "abstractui.h"
#include "boardobserver.h"

AbstractUI::AbstractUI(Board* board, GameData* gameData) : board{board}, gameData{gameData} {}



