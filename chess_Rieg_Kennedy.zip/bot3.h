#pragma once
#include "bot.h"

class Bot3 : public Bot {
    
    public:
    Bot3(Board* board, Colour colour);
    MoveInfo makeMove() override;
    
};
